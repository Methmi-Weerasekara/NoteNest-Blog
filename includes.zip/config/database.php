<?php

$host = "sql102.infinityfree.com ";
$username = "if0_42711415";
$password = "aT4HVotkvVAnQy";
$database = "f0_42711415_notenest_db";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

?>